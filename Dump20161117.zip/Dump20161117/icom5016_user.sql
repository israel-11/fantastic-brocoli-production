CREATE DATABASE  IF NOT EXISTS `icom5016` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `icom5016`;
-- MySQL dump 10.13  Distrib 5.5.35, for Linux (x86_64)
--
-- Host: mysql4.gear.host    Database: icom5016
-- ------------------------------------------------------
-- Server version	5.7.16-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user` (
  `userId` varchar(20) NOT NULL,
  `userFirstName` varchar(20) DEFAULT NULL,
  `userLastName` varchar(20) DEFAULT NULL,
  `userImage` varchar(8000) DEFAULT NULL,
  `userEmail` varchar(50) DEFAULT NULL,
  `userPassword` varchar(20) DEFAULT NULL,
  `isTutor` tinyint(1) DEFAULT NULL,
  `userStatus` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`userId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES ('1','Israel','Figueroa','https://scontent-atl3-1.xx.fbcdn.net/v/t1.0-9/14724397_1206577912739845_4904131675000625869_n.jpg?oh=ff5b1a56c65403fa5b38d28a8b5d71e5&oe=589522A8','israel.figueroa@upr.edu','qwerty',1,'Hey I am a tutor.'),('2','Nelson','Alemar','https://fbcdn-profile-a.akamaihd.net/hprofile-ak-xtf1/v/t1.0-1/13912618_10154625059185827_4804033282118954744_n.jpg?oh=71c307466a6f3cf85ffc580d1a588c02&oe=58C703DB&__gda__=1485738904_e299d10033dcc5340dcf7c055ddfd831','nelson.alemar@upr.edu','qwerty',0,'Hey I am a student.'),('3','Tahiri','Fuentes','https://scontent.xx.fbcdn.net/v/t1.0-9/11896161_10152903169742924_4252561626830461511_n.jpg?oh=031b09d9f105c89617e00e7832ea8b2e&oe=588F0CAE',NULL,NULL,NULL,NULL),('4','Graciany','Lebron','https://scontent.xx.fbcdn.net/v/t1.0-9/13321873_1069331569807282_7538641489178603008_n.jpg?oh=5591547c1547d14e6dc3c44b1e006a70&oe=58C4C7CB',NULL,NULL,NULL,NULL),('5','Wilson','Velez','https://scontent.xx.fbcdn.net/v/t1.0-9/25995_484241461621806_907774178_n.jpg?oh=8fb7a9421523c146b691b234c65c427d&oe=58CDB4BB',NULL,NULL,NULL,NULL),('6','Walmari','Ortiz','https://scontent.xx.fbcdn.net/v/t1.0-9/11863509_859551770807825_8297309958520298530_n.jpg?oh=c5a39d81cbaf4d3d08befda53b3a5542&oe=58CCFF60',NULL,NULL,NULL,NULL),('7','Fernando','Arocho','https://scontent.xx.fbcdn.net/v/t1.0-9/10678814_10202869666254657_6916432225151333459_n.jpg?oh=37194be244b9aebc923a4bd2219a5060&oe=58CC0A3E','',NULL,NULL,NULL),('8','Luis','Millan','https://scontent.xx.fbcdn.net/v/t1.0-9/430225_10151816407266677_906672085_n.jpg?oh=b98f81d61c322bf80bbf8651199f66a6&oe=58D4E81C',NULL,NULL,NULL,NULL),('9','Ricky','Rosello','http://www.80grados.net/wp-content/uploads/2012/08/ricky-rossell%C3%B3.jpeg',NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-11-17 23:59:13
